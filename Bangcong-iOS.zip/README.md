# Bảng công cá nhân – bản iOS (SwiftUI)

Bản iOS viết lại bằng SwiftUI từ app Android (Kotlin/Compose). Logic tính lương, lịch âm, ngày lễ, định dạng JSON giữ nguyên
nên file sao lưu `.json` xuất từ Android nhập vào đây được (và ngược lại).

Build: GitHub Actions (macOS) -> XcodeGen tạo `Bangcong.xcodeproj` từ `project.yml` -> `xcodebuild` ra `Bangcong.ipa` chưa ký.
Tải ở tab Actions -> lần chạy -> Artifacts `Bangcong-ipa`, rồi ký bằng ESign/GBox.

Đã có: 4 tab (Tổng quan, Tăng ca, Lương, Thêm), chấm công + chú thích tuỳ chỉnh (đọc từ JSON), kỳ công, âm lịch, ngày lễ VN,
tính lương đầy đủ (OT, đêm, thứ 7/CN, bảo hiểm, thưởng), PIN + Face ID, nhắc chấm công T2–T6, sáng/tối + 4 tông màu, xuất/nhập JSON.

Chưa có (so với Android): widget, sao lưu Google Drive, xuất Excel, chia sẻ ảnh/PDF bảng công, sửa chú thích, tiếng Anh.
