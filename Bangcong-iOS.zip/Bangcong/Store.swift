import Foundation
import SwiftUI
import CryptoKit

private func dbl(_ o: [String: Any], _ k: String, _ def: Double) -> Double {
    (o[k] as? NSNumber)?.doubleValue ?? def
}
private func i64(_ o: [String: Any], _ k: String, _ def: Int64) -> Int64 {
    (o[k] as? NSNumber)?.int64Value ?? def
}
private func int(_ o: [String: Any], _ k: String, _ def: Int) -> Int {
    (o[k] as? NSNumber)?.intValue ?? def
}
private func bool(_ o: [String: Any], _ k: String, _ def: Bool) -> Bool {
    (o[k] as? NSNumber)?.boolValue ?? def
}
private func clampI(_ v: Int, _ lo: Int, _ hi: Int) -> Int { min(max(v, lo), hi) }

private let legendDefaults: [String: (String, String)] = [
    "full": ("1 ngày công", "#2f6fed"),
    "half": ("Nửa ngày", "#8fb8ff"),
    "leave": ("Nghỉ phép năm", "#f4c20d"),
    "absent": ("Nghỉ không phép", "#f0736b"),
    "empty": ("Chưa chấm", "#eef1f6"),
    "weekend": ("Nghỉ cuối tuần (T7, CN)", "#4caf50"),
    "holiday": ("Ngày lễ", "#e53935"),
]
let LEGEND_KEYS = ["full", "half", "leave", "absent", "empty", "weekend", "holiday"]

/// Dữ liệu dùng chung định dạng JSON với bản Android (bangcong_personal.json):
/// xuất file từ Android rồi nhập vào đây (và ngược lại) là dùng được.
final class Store: ObservableObject {
    @Published var rev = 0
    @Published var unlocked = false
    @Published var corruptNotice = false

    private(set) var root: [String: Any] = [:]
    private let fileURL: URL
    private var holidayCache: Set<String>?
    private var settingsCache: PayrollSettings?
    private let ud = UserDefaults.standard

    init() {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        fileURL = dir.appendingPathComponent("bangcong_personal.json")
        load()
        if normalizeOtIds() { save() }
    }

    // MARK: - Lưu / đọc
    private func load() {
        guard FileManager.default.fileExists(atPath: fileURL.path) else { return }
        do {
            let data = try Data(contentsOf: fileURL)
            if let o = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                root = o
            } else {
                throw NSError(domain: "bc", code: 1)
            }
        } catch {
            corruptNotice = true
            let bak = fileURL.deletingLastPathComponent().appendingPathComponent("bangcong_personal.corrupt.json")
            try? FileManager.default.removeItem(at: bak)
            try? FileManager.default.copyItem(at: fileURL, to: bak)
            root = [:]
        }
    }

    private func save() {
        holidayCache = nil
        settingsCache = nil
        if let data = try? JSONSerialization.data(withJSONObject: root, options: [.sortedKeys]) {
            try? data.write(to: fileURL, options: .atomic)
        }
        rev += 1
    }

    private func normalizeOtIds() -> Bool {
        guard var a = root["ot"] as? [[String: Any]] else { return false }
        var used = Set<Int64>()
        var next = Int64(Date().timeIntervalSince1970 * 1000)
        var changed = false
        for i in 0..<a.count {
            let id = (a[i]["id"] as? NSNumber)?.int64Value ?? -1
            if id <= 0 || used.contains(id) {
                repeat { next += 1 } while used.contains(next)
                a[i]["id"] = next
                used.insert(next)
                changed = true
            } else {
                used.insert(id)
            }
        }
        if changed { root["ot"] = a }
        return changed
    }

    private func dict(_ k: String) -> [String: Any] { root[k] as? [String: Any] ?? [:] }
    private func newId() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }

    // MARK: - Hồ sơ & cài đặt
    var profileName: String { dict("profile")["name"] as? String ?? "" }
    var profileCode: String { dict("profile")["code"] as? String ?? "" }
    var profilePosition: String { dict("profile")["position"] as? String ?? "" }
    var profileDepartment: String { dict("profile")["department"] as? String ?? "" }
    var theme: String { root["theme"] as? String ?? "system" }
    var tone: String { root["tone"] as? String ?? "lavender" }
    var periodStartDay: Int { clampI(int(dict("settings"), "periodStart", 1), 1, 31) }
    var company: String {
        let c = dict("settings")["company"] as? String ?? ""
        return c.trimmingCharacters(in: .whitespaces).isEmpty ? "Bảng công" : c
    }

    func saveProfile(name: String, code: String, position: String, department: String) {
        var p = dict("profile")
        p["name"] = name
        p["code"] = code
        p["position"] = position
        p["department"] = department
        root["profile"] = p
        save()
    }

    func setCompany(_ name: String) {
        var s = dict("settings")
        s["company"] = name.trimmingCharacters(in: .whitespaces)
        root["settings"] = s
        save()
    }

    func setPeriodStart(_ day: Int) {
        var s = dict("settings")
        s["periodStart"] = clampI(day, 1, 31)
        root["settings"] = s
        save()
    }

    func setTheme(_ t: String) { root["theme"] = t; save() }
    func setTone(_ t: String) { root["tone"] = t; save() }

    var reminderOn: Bool { bool(dict("settings"), "reminderOn", false) }
    var reminderHour: Int { clampI(int(dict("settings"), "reminderHour", 17), 0, 23) }
    var reminderMinute: Int { clampI(int(dict("settings"), "reminderMinute", 30), 0, 59) }

    func setReminder(on: Bool, hour: Int, minute: Int) {
        var s = dict("settings")
        s["reminderOn"] = on
        s["reminderHour"] = clampI(hour, 0, 23)
        s["reminderMinute"] = clampI(minute, 0, 59)
        root["settings"] = s
        save()
        if on { Reminder.schedule(hour: hour, minute: minute) } else { Reminder.cancel() }
    }

    // MARK: - Kỳ công
    func periodOf(_ anchor: Date, startDay: Int? = nil) -> Period {
        let sd = clampI(startDay ?? periodStartDay, 1, 31)
        var y = anchor.yr
        var m = anchor.mon
        if anchor.dom < min(sd, daysIn(y, m)) {
            (y, m) = addMonths(y, m, -1)
        }
        let start = makeDate(y, m, min(sd, daysIn(y, m)))
        let (ny, nm) = addMonths(y, m, 1)
        let next = makeDate(ny, nm, min(sd, daysIn(ny, nm)))
        return Period(start: start, end: next.plusDays(-1))
    }

    func shiftPeriod(_ p: Period, _ delta: Int) -> Period {
        let (y, m) = addMonths(p.start.yr, p.start.mon, delta)
        return periodOf(makeDate(y, m, min(periodStartDay, daysIn(y, m))))
    }

    // MARK: - Chú giải
    private func customArray() -> [[String: Any]] {
        (dict("legend")["custom"] as? [[String: Any]]) ?? []
    }

    func legendLabel(_ key: String) -> String {
        if key.hasPrefix("x:") {
            let id = String(key.dropFirst(2))
            return customArray().first(where: { ($0["id"] as? String) == id })?["label"] as? String ?? "Chú thích"
        }
        if let o = dict("legend")[key] as? [String: Any], let l = o["label"] as? String,
           !l.trimmingCharacters(in: .whitespaces).isEmpty { return l }
        return legendDefaults[key]?.0 ?? key
    }

    func legendColor(_ key: String) -> String {
        if key.hasPrefix("x:") {
            let id = String(key.dropFirst(2))
            return customArray().first(where: { ($0["id"] as? String) == id })?["color"] as? String ?? "#cccccc"
        }
        if let o = dict("legend")[key] as? [String: Any], let c = o["color"] as? String, !c.isEmpty { return c }
        return legendDefaults[key]?.1 ?? "#cccccc"
    }

    func customLegend() -> [LegendItem] {
        customArray().map { c in
            let id = c["id"] as? String ?? ""
            return LegendItem(key: "x:" + id,
                              label: c["label"] as? String ?? "Chú thích",
                              color: c["color"] as? String ?? "#cccccc",
                              code: c["code"] as? String ?? "★")
        }
    }

    // MARK: - Ngày công
    func isHoliday(_ d: Date) -> Bool {
        if holidayCache == nil {
            var set = Set<String>()
            if let h = root["holidays"] as? [Any] {
                for x in h { if let s = x as? String { set.insert(s) } }
            }
            holidayCache = set
        }
        return holidayCache?.contains(d.key) ?? false
    }

    func dayMark(_ d: Date) -> DayMark? {
        guard let wd = root["workday"] as? [String: Any], let v = wd[d.key] else { return nil }
        if let s = v as? String {
            if s == "P" { return .leave }
            if s == "O" { return .absent }
            if s.hasPrefix("x:") { return .custom(s) }
            return nil
        }
        if let n = v as? NSNumber {
            let x = n.doubleValue
            if x == 1.0 { return .full }
            if x == 0.5 { return .half }
        }
        return nil
    }

    func setDayMark(_ d: Date, _ mark: DayMark?) {
        var wd = dict("workday")
        if let m = mark { wd[d.key] = m.json } else { wd.removeValue(forKey: d.key) }
        root["workday"] = wd
        save()
    }

    func isOffDay(_ d: Date) -> Bool {
        let w = d.dow
        if w != 6 && w != 7 { return false }
        guard let o = root["payroll"] as? [String: Any] else { return true }
        if w == 6 { return !isSatWorkday(d, readSatMask(o)) }
        return !isSunWorkday(d, clampI(int(o, "sunWorkMask", 0), 0, 31))
    }

    func renderKey(_ d: Date) -> String {
        if isHoliday(d) { return "holiday" }
        if let m = dayMark(d) { return m.legendKey }
        if isOffDay(d) { return "weekend" }
        return "empty"
    }

    func summary(_ p: Period) -> Summary {
        var s = Summary(work: 0, ot: 0, leaveP: 0, absentO: 0)
        for d in p.days {
            guard let m = dayMark(d) else { continue }
            switch m {
            case .full: s.work += 1
            case .half: s.work += 0.5
            case .leave: s.leaveP += 1
            case .absent: s.absentO += 1
            case .custom: break
            }
        }
        for e in otEntries(p) { s.ot += e.hours }
        return s
    }

    // MARK: - Cài đặt lương
    var payrollSettings: PayrollSettings {
        if let c = settingsCache { return c }
        let s = readPayrollSettings()
        settingsCache = s
        return s
    }

    private func readSatMask(_ o: [String: Any]) -> Int {
        if o["satWorkMask"] != nil { return clampI(int(o, "satWorkMask", 0), 0, 31) }
        return bool(o, "saturdayOff", true) ? 0 : 31
    }

    private func readPayrollSettings() -> PayrollSettings {
        let o = dict("payroll")
        var s = PayrollSettings()
        s.monthly = max(i64(o, "monthly", 0), 0)
        let sd = dbl(o, "stdDays", 23)
        s.stdDays = sd > 0 ? sd : 23
        s.allowance = max(i64(o, "allowance", 0), 0)
        s.paidLeave = bool(o, "paidLeave", true)
        s.rateNormal = clampI(int(o, "rateNormal", 150), 100, 1000)
        s.rateWeekend = clampI(int(o, "rateWeekend", 200), 100, 1000)
        s.rateHoliday = clampI(int(o, "rateHoliday", 300), 100, 1000)
        s.satWorkMask = readSatMask(o)
        let sv = dbl(o, "satDayValue", 1.0)
        s.satDayValue = (sv > 0 && sv <= 1) ? sv : 1.0
        if o["rateSaturday"] != nil {
            s.rateSaturday = clampI(int(o, "rateSaturday", 200), 100, 1000)
        } else {
            s.rateSaturday = s.rateWeekend
        }
        s.autoHoliday = bool(o, "autoHoliday", true)
        s.sunWorkMask = clampI(int(o, "sunWorkMask", 0), 0, 31)
        let uv = dbl(o, "sunDayValue", 1.0)
        s.sunDayValue = (uv > 0 && uv <= 1) ? uv : 1.0
        s.restByHours = bool(o, "restByHours", false)
        let hp = dbl(o, "hoursPerDay", 8.0)
        s.hoursPerDay = (hp >= 1 && hp <= 24) ? hp : 8.0
        s.stdAuto = bool(o, "stdAuto", false)
        s.otBaseMode = clampI(int(o, "otBaseMode", 0), 0, 2)
        s.basic = max(i64(o, "basic", 0), 0)
        s.otBaseAmount = max(i64(o, "otBaseAmount", 0), 0)
        let os = dbl(o, "otStdDays", 0)
        s.otStdDays = (os >= 1 && os <= 31) ? os : 0
        s.insOn = bool(o, "insOn", false)
        s.insBase = max(i64(o, "insBase", 0), 0)
        let ip = dbl(o, "insPct", 10.5)
        s.insPct = (ip > 0 && ip <= 30) ? ip : 10.5
        return s
    }

    func savePayrollSettings(_ s: PayrollSettings) {
        var o = dict("payroll")
        o["monthly"] = s.monthly
        o["stdDays"] = s.stdDays
        o["allowance"] = s.allowance
        o["paidLeave"] = s.paidLeave
        o["rateNormal"] = s.rateNormal
        o["rateWeekend"] = s.rateWeekend
        o["rateHoliday"] = s.rateHoliday
        o["satWorkMask"] = s.satWorkMask
        o["satDayValue"] = s.satDayValue
        o["rateSaturday"] = s.rateSaturday
        o["saturdayOff"] = s.satWorkMask != 31
        o["autoHoliday"] = s.autoHoliday
        o["sunWorkMask"] = s.sunWorkMask
        o["sunDayValue"] = s.sunDayValue
        o["restByHours"] = s.restByHours
        o["hoursPerDay"] = s.hoursPerDay
        o["stdAuto"] = s.stdAuto
        o["otBaseMode"] = s.otBaseMode
        o["basic"] = s.basic
        o["otBaseAmount"] = s.otBaseAmount
        o["otStdDays"] = s.otStdDays
        o["insOn"] = s.insOn
        o["insBase"] = s.insBase
        o["insPct"] = s.insPct
        root["payroll"] = o
        save()
    }

    func autoStdDays(_ p: Period, _ s: PayrollSettings) -> Double {
        var n = 0.0
        for d in p.days {
            if isRestDay(d, s) { continue }
            switch d.dow {
            case 6: n += s.satDayValue
            case 7: n += s.sunDayValue
            default: n += 1.0
            }
        }
        return n
    }

    /// Lương tạm tính của kỳ: chuyển nguyên công thức từ bản Android.
    func payroll(_ p: Period) -> Payroll {
        let s = payrollSettings
        let sum = summary(p)
        var restSat = 0.0
        var restSun = 0.0
        for d in p.days {
            guard let m = dayMark(d), m.work > 0 else { continue }
            if isHoliday(d) || !isRestDay(d, s) { continue }
            if d.dow == 6 { restSat += m.work } else { restSun += m.work }
        }
        let leaveAdd = s.paidLeave ? Double(sum.leaveP) : 0.0
        let workDays = sum.work - restSat - restSun + leaveAdd
        var stdUsed = s.stdDays
        if s.stdAuto {
            let a = autoStdDays(p, s)
            stdUsed = a > 0 ? a : s.stdDays
        }
        let dayRate = Double(s.monthly) / stdUsed
        let otStd = s.otStdDays > 0 ? s.otStdDays : stdUsed
        let otDayRate = Double(s.otBase) / otStd
        let hourRate = Double(rnd(otDayRate / s.hoursPerDay))
        var holidayDays = 0.0
        if s.autoHoliday {
            for d in p.days {
                if isHoliday(d) && dayMark(d) == nil && !isRestDay(d, s) {
                    switch d.dow {
                    case 6: holidayDays += s.satDayValue
                    case 7: holidayDays += s.sunDayValue
                    default: holidayDays += 1.0
                    }
                }
            }
        }
        var hN = 0.0, hW = 0.0, hS = 0.0, hH = 0.0, hNight = 0.0, nightExtra = 0.0
        for e in otEntries(p) {
            var rate = s.rateNormal
            if isHoliday(e.date) {
                hH += e.hours; rate = s.rateHoliday
            } else if e.date.dow == 6 && isRestDay(e.date, s) {
                hS += e.hours; rate = s.rateSaturday
            } else if isRestDay(e.date, s) {
                hW += e.hours; rate = s.rateWeekend
            } else {
                hN += e.hours; rate = s.rateNormal
            }
            let night = min(nightHoursOf(e.from, e.to), e.hours)
            hNight += night
            nightExtra += night * (0.30 + 0.20 * Double(rate) / 100.0)
        }
        let base = rnd(workDays * dayRate)
        let holidayPay = rnd(holidayDays * dayRate)
        let otN = rnd(hN * hourRate * Double(s.rateNormal) / 100.0)
        let otW = rnd(hW * hourRate * Double(s.rateWeekend) / 100.0)
        let otS = rnd(hS * hourRate * Double(s.rateSaturday) / 100.0)
        let otH = rnd(hH * hourRate * Double(s.rateHoliday) / 100.0)
        let otNight = rnd(nightExtra * hourRate)
        let restSatPay: Int64 = s.restByHours ? 0 : rnd(restSat * otDayRate * Double(s.rateSaturday) / 100.0)
        let restSunPay: Int64 = s.restByHours ? 0 : rnd(restSun * otDayRate * Double(s.rateWeekend) / 100.0)
        let extra = extraEntries(p).reduce(Int64(0)) { $0 + $1.amount }
        var insurance: Int64 = 0
        if s.insOn {
            let insBase = s.insBase > 0 ? s.insBase : s.monthly
            insurance = rnd(Double(insBase) * s.insPct / 100.0)
        }
        var total = base + holidayPay + otN + otW + otS + otH
        total += otNight + restSatPay + restSunPay + s.allowance + extra

        var r = Payroll()
        r.configured = s.monthly > 0
        r.workDays = workDays; r.dayRate = dayRate; r.hourRate = hourRate
        r.base = base
        r.hoursNormal = hN; r.hoursWeekend = hW; r.hoursHoliday = hH
        r.otNormal = otN; r.otWeekend = otW; r.otHoliday = otH
        r.allowance = s.allowance; r.total = total
        r.holidayDays = holidayDays; r.holidayPay = holidayPay
        r.hoursNight = hNight; r.otNight = otNight
        r.hoursSaturday = hS; r.otSaturday = otS
        r.restSatDays = restSat; r.restSunDays = restSun
        r.restSatPay = restSatPay; r.restSunPay = restSunPay
        r.stdUsed = stdUsed; r.otDayRate = otDayRate
        r.insurance = insurance; r.net = total - insurance; r.extra = extra
        return r
    }

    // MARK: - Tăng ca (OT)
    func otEntries(_ p: Period? = nil) -> [OtEntry] {
        guard let a = root["ot"] as? [[String: Any]] else { return [] }
        var out: [OtEntry] = []
        for x in a {
            guard let ds = x["date"] as? String, let date = parseDate(ds) else { continue }
            if let p = p, !p.contains(date) { continue }
            out.append(OtEntry(id: i64(x, "id", -1), date: date,
                               from: x["from"] as? String ?? "", to: x["to"] as? String ?? "",
                               hours: dbl(x, "hours", 0), reason: x["reason"] as? String ?? ""))
        }
        return out
    }

    func addOt(date: Date, from: String, to: String, hours: Double, reason: String) {
        var a = root["ot"] as? [[String: Any]] ?? []
        let o: [String: Any] = [
            "id": newId(), "date": date.key, "from": from, "to": to, "hours": hours,
            "reason": reason.trimmingCharacters(in: .whitespaces),
            "createdAt": ISO8601DateFormatter().string(from: Date()),
        ]
        a.append(o)
        root["ot"] = a
        save()
    }

    func updateOt(id: Int64, date: Date, from: String, to: String, hours: Double, reason: String) {
        guard var a = root["ot"] as? [[String: Any]] else { return }
        for i in 0..<a.count where i64(a[i], "id", -1) == id {
            a[i]["date"] = date.key
            a[i]["from"] = from
            a[i]["to"] = to
            a[i]["hours"] = hours
            a[i]["reason"] = reason.trimmingCharacters(in: .whitespaces)
            a[i]["updatedAt"] = ISO8601DateFormatter().string(from: Date())
            break
        }
        root["ot"] = a
        save()
    }

    func deleteOt(_ id: Int64) { removeById("ot", id) }

    // MARK: - Phụ cấp thêm / thưởng
    func extraEntries(_ p: Period? = nil) -> [ExtraEntry] {
        guard let a = root["extras"] as? [[String: Any]] else { return [] }
        var out: [ExtraEntry] = []
        for x in a {
            guard let ds = x["date"] as? String, let date = parseDate(ds) else { continue }
            if let p = p, !p.contains(date) { continue }
            out.append(ExtraEntry(id: i64(x, "id", -1), date: date, amount: i64(x, "amount", 0),
                                  note: x["note"] as? String ?? ""))
        }
        return out
    }

    func addExtra(date: Date, amount: Int64, note: String) {
        var a = root["extras"] as? [[String: Any]] ?? []
        a.append(["id": newId(), "date": date.key, "amount": amount,
                  "note": note.trimmingCharacters(in: .whitespaces)])
        root["extras"] = a
        save()
    }

    func deleteExtra(_ id: Int64) { removeById("extras", id) }

    private func removeById(_ key: String, _ id: Int64) {
        guard let a = root[key] as? [[String: Any]] else { return }
        root[key] = a.filter { i64($0, "id", -1) != id }
        save()
    }

    // MARK: - Ngày lễ
    func holidays() -> [Date] {
        guard let h = root["holidays"] as? [Any] else { return [] }
        var out: [Date] = []
        for x in h { if let s = x as? String, let d = parseDate(s) { out.append(d) } }
        return out.sorted()
    }

    func addHolidays(_ days: [Date]) -> Int {
        var a = (root["holidays"] as? [Any]) ?? []
        var have = Set<String>()
        for x in a { if let s = x as? String { have.insert(s) } }
        var added = 0
        for d in days where !have.contains(d.key) {
            have.insert(d.key)
            a.append(d.key)
            added += 1
        }
        if added > 0 {
            root["holidays"] = a
            save()
        }
        return added
    }

    func removeHoliday(_ d: Date) {
        guard let a = root["holidays"] as? [Any] else { return }
        root["holidays"] = a.filter { ($0 as? String) != d.key }
        save()
    }

    // MARK: - Khoá PIN
    private var pinHash: String { ud.string(forKey: "bc.pinHash") ?? "" }
    private var pinSalt: String { ud.string(forKey: "bc.pinSalt") ?? "" }
    var hasPin: Bool { !pinHash.isEmpty }
    var pinRequired: Bool { hasPin && !unlocked }
    var biometricOn: Bool { hasPin && ud.bool(forKey: "bc.biometric") }

    private func hash(_ pin: String, salt: String) -> String {
        var data = Data((salt + ":" + pin).utf8)
        for _ in 0..<60000 { data = Data(SHA256.hash(data: data)) }
        return data.base64EncodedString()
    }

    func setBiometric(_ on: Bool) {
        ud.set(on, forKey: "bc.biometric")
        rev += 1
    }

    func setPin(_ p: String) {
        let digits = String(p.filter { $0.isNumber }.prefix(8))
        if digits.isEmpty {
            ud.removeObject(forKey: "bc.pinHash")
            ud.removeObject(forKey: "bc.pinSalt")
            ud.set(false, forKey: "bc.biometric")
        } else {
            let salt = UUID().uuidString
            ud.set(salt, forKey: "bc.pinSalt")
            ud.set(hash(digits, salt: salt), forKey: "bc.pinHash")
        }
        unlocked = true
        rev += 1
    }

    func lock() { if hasPin { unlocked = false } }

    func lockoutRemaining() -> TimeInterval {
        max(0, ud.double(forKey: "bc.lockUntil") - Date().timeIntervalSince1970)
    }

    func tryUnlock(_ input: String) -> Bool {
        if lockoutRemaining() > 0 { return false }
        if hash(input, salt: pinSalt) != pinHash {
            let n = ud.integer(forKey: "bc.fails") + 1
            ud.set(n, forKey: "bc.fails")
            if n >= 5 {
                let secs = min(30.0 * pow(2.0, Double(min(n - 5, 7))), 3600.0)
                ud.set(Date().timeIntervalSince1970 + secs, forKey: "bc.lockUntil")
            }
            return false
        }
        ud.set(0, forKey: "bc.fails")
        ud.set(0.0, forKey: "bc.lockUntil")
        unlocked = true
        return true
    }

    func unlockWithBiometric() {
        unlocked = true
        ud.set(0, forKey: "bc.fails")
    }

    // MARK: - Xuất / nhập / xoá
    func exportJSON() -> Data {
        (try? JSONSerialization.data(withJSONObject: root, options: [.prettyPrinted, .sortedKeys])) ?? Data()
    }

    func exportFileURL() -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("bangcong_backup.json")
        try? exportJSON().write(to: url, options: .atomic)
        return url
    }

    private let backupKeys = ["workday", "ot", "profile", "settings", "holidays", "legend", "theme", "records", "payroll", "extras"]

    func importJSON(_ data: Data) -> Bool {
        var text = String(decoding: data, as: UTF8.self)
        text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.hasPrefix("\u{FEFF}") { text.removeFirst() }
        guard let d = text.data(using: .utf8),
              let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any],
              backupKeys.contains(where: { o[$0] != nil }) else { return false }
        if FileManager.default.fileExists(atPath: fileURL.path) {
            let bak = fileURL.deletingLastPathComponent().appendingPathComponent("bangcong_personal.before_import.json")
            try? FileManager.default.removeItem(at: bak)
            try? FileManager.default.copyItem(at: fileURL, to: bak)
        }
        let keepTheme = theme
        let keepTone = tone
        root = o
        root["theme"] = keepTheme
        root["tone"] = keepTone
        if var s = root["settings"] as? [String: Any] {
            for k in ["pin", "pinHash", "pinSalt", "biometric"] { s.removeValue(forKey: k) }
            root["settings"] = s
        }
        _ = normalizeOtIds()
        save()
        return true
    }

    func resetAll() {
        root = [:]
        for k in ["bc.pinHash", "bc.pinSalt", "bc.biometric", "bc.fails", "bc.lockUntil"] { ud.removeObject(forKey: k) }
        let dir = fileURL.deletingLastPathComponent()
        for n in ["bangcong_personal.before_import.json", "bangcong_personal.corrupt.json"] {
            try? FileManager.default.removeItem(at: dir.appendingPathComponent(n))
        }
        Reminder.cancel()
        unlocked = false
        save()
    }
}
