import SwiftUI

struct DayPick: Identifiable {
    let date: Date
    var id: String { date.key }
}

struct PeriodNav: View {
    @Environment(\.pal) var pal
    let title: String
    let onPrev: () -> Void
    let onNext: () -> Void

    var body: some View {
        HStack {
            Button(action: onPrev) {
                Image(systemName: "chevron.left").font(.system(size: 16, weight: .bold))
                    .frame(width: 38, height: 38).background(pal.card2).clipShape(Circle())
            }
            Spacer()
            Text(title).font(.system(size: 15, weight: .bold)).foregroundColor(pal.text)
            Spacer()
            Button(action: onNext) {
                Image(systemName: "chevron.right").font(.system(size: 16, weight: .bold))
                    .frame(width: 38, height: 38).background(pal.card2).clipShape(Circle())
            }
        }
        .foregroundColor(pal.primary)
    }
}

struct HomeView: View {
    @EnvironmentObject var store: Store
    @Environment(\.pal) var pal
    @Binding var tab: Int
    @State var anchor = Date().dayStart
    @State var pick: DayPick?

    private var today: Date { Date().dayStart }

    var body: some View {
        let p = store.periodOf(anchor)
        let sum = store.summary(p)
        ScrollView {
            VStack(spacing: 12) {
                heroCard
                statsCard(p, sum)
                payrollPeek(p)
                calendarCard(p)
            }
            .padding(16)
        }
        .background(pal.bg.ignoresSafeArea())
        .sheet(item: $pick) { item in
            MarkSheet(date: item.date) { mark in
                store.setDayMark(item.date, mark)
                pick = nil
            }
            .presentationDetents([.medium, .large])
        }
    }

    // MARK: Thẻ hôm nay
    private var heroCard: some View {
        let d = today
        let l = Lunar.fromSolar(d.dom, d.mon, d.yr)
        var lunarText = "Âm lịch: \(l.day)/\(l.month)"
        if l.leap { lunarText += " (nhuận)" }
        let mark = store.dayMark(d)
        let status: String = mark == nil ? "Hôm nay chưa chấm công" : "Hôm nay: " + store.legendLabel(mark!.legendKey)
        return VStack(alignment: .leading, spacing: 8) {
            Text(store.company).font(.caption.bold()).foregroundColor(.white.opacity(0.8))
            Text("\(WEEKDAYS[d.dow - 1]), \(fmtDate(d))").font(.title3.bold()).foregroundColor(.white)
            Text(lunarText).font(.footnote).foregroundColor(.white.opacity(0.85))
            Text(status).font(.subheadline).foregroundColor(.white)
            Button {
                pick = DayPick(date: d)
            } label: {
                Text(mark == nil ? "Chấm công hôm nay" : "Đổi trạng thái hôm nay")
                    .font(.system(size: 15, weight: .bold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(Color.white)
                    .foregroundColor(pal.hero)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(
            LinearGradient(colors: [pal.hero, pal.primary2], startPoint: .topLeading, endPoint: .bottomTrailing)
        )
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    // MARK: Số liệu
    private func statsCard(_ p: Period, _ s: Summary) -> some View {
        HStack(spacing: 0) {
            stat("Kỳ công T\(p.monthOfPeriod)", fmtNum(s.work), "công", pal.primary)
            stat("Tăng ca", fmtNum(s.ot), "giờ", pal.primary2)
            stat("Nghỉ phép", "\(s.leaveP)", "ngày", Color(hex: "d49b00"))
            stat("Không phép", "\(s.absentO)", "ngày", Color(hex: "E5564D"))
        }
        .card()
    }

    private func stat(_ title: String, _ value: String, _ unit: String, _ color: Color) -> some View {
        VStack(spacing: 2) {
            Text(title).font(.system(size: 11, weight: .semibold)).foregroundColor(pal.muted).lineLimit(1)
            Text(value).font(.system(size: 22, weight: .heavy)).foregroundColor(color)
            Text(unit).font(.system(size: 11)).foregroundColor(pal.muted)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: Lương tạm tính
    private func payrollPeek(_ p: Period) -> some View {
        let r = store.payroll(p)
        return Button {
            tab = 2
        } label: {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Lương tạm tính").font(.caption.bold()).foregroundColor(.white.opacity(0.85))
                    if r.configured {
                        Text(fmtMoney(r.net)).font(.title2.bold()).foregroundColor(.white)
                    } else {
                        Text("Chưa cài đặt lương").font(.headline).foregroundColor(.white)
                    }
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundColor(.white.opacity(0.8))
            }
            .padding(16)
            .background(
                LinearGradient(colors: [pal.primary2, pal.hero], startPoint: .leading, endPoint: .trailing)
            )
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    // MARK: Lịch
    private func shift(_ delta: Int) {
        anchor = store.shiftPeriod(store.periodOf(anchor), delta).start
    }

    private func calendarCard(_ p: Period) -> some View {
        let lead = p.start.dow - 1
        var cells: [Date?] = Array(repeating: nil, count: lead)
        for d in p.days { cells.append(d) }
        let cols = Array(repeating: GridItem(.flexible(), spacing: 5), count: 7)
        let otDays = Set(store.otEntries(p).filter { $0.hours > 0 }.map { $0.date.key })
        let todayKey = today.key
        let title = "\(fmtDate(p.start)) → \(fmtDate(p.end))"
        return VStack(spacing: 10) {
            PeriodNav(title: title, onPrev: { shift(-1) }, onNext: { shift(1) })
            HStack(spacing: 5) {
                ForEach(0..<7, id: \.self) { i in
                    Text(SHORT[i]).font(.caption.bold())
                        .foregroundColor(i >= 5 ? pal.primary : pal.muted)
                        .frame(maxWidth: .infinity)
                }
            }
            LazyVGrid(columns: cols, spacing: 5) {
                ForEach(0..<cells.count, id: \.self) { i in
                    if let d = cells[i] {
                        DayCell(date: d, isToday: d.key == todayKey, hasOt: otDays.contains(d.key))
                            .onTapGesture { pick = DayPick(date: d) }
                    } else {
                        Color.clear.frame(height: 46)
                    }
                }
            }
            Divider()
            LegendStrip()
        }
        .card()
        .simultaneousGesture(
            DragGesture(minimumDistance: 40).onEnded { v in
                if abs(v.translation.width) > abs(v.translation.height) * 1.5 {
                    if v.translation.width > 60 { shift(-1) }
                    else if v.translation.width < -60 { shift(1) }
                }
            }
        )
    }
}

struct DayCell: View {
    @EnvironmentObject var store: Store
    @Environment(\.pal) var pal
    let date: Date
    let isToday: Bool
    let hasOt: Bool

    private func code(_ key: String) -> String {
        switch key {
        case "full": return "1"
        case "half": return "½"
        case "leave": return "P"
        case "absent": return "O"
        default:
            if key.hasPrefix("x:") {
                return store.customLegend().first(where: { $0.key == key })?.code ?? "★"
            }
            return ""
        }
    }

    var body: some View {
        let key = store.renderKey(date)
        let hex = store.legendColor(key)
        let bg: Color = key == "empty" ? pal.card2 : Color(hex: hex)
        let fg: Color = key == "empty" ? pal.text : (isLightHex(hex) ? Color.black.opacity(0.85) : Color.white)
        ZStack(alignment: .topTrailing) {
            VStack(spacing: 0) {
                Text("\(date.dom)").font(.system(size: 15, weight: .bold))
                Text(code(key)).font(.system(size: 10, weight: .semibold)).opacity(0.85)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 46)
            .foregroundColor(fg)
            .background(bg)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(isToday ? pal.primary : Color.clear, lineWidth: 2.5)
            )
            if hasOt {
                Circle().fill(Color.orange).frame(width: 8, height: 8).padding(4)
            }
        }
        .contentShape(Rectangle())
    }
}

struct LegendStrip: View {
    @EnvironmentObject var store: Store
    @Environment(\.pal) var pal

    var body: some View {
        let keys = ["full", "half", "leave", "absent", "weekend", "holiday"] + store.customLegend().map { $0.key }
        let cols = [GridItem(.flexible(), alignment: .leading), GridItem(.flexible(), alignment: .leading)]
        LazyVGrid(columns: cols, spacing: 6) {
            ForEach(keys, id: \.self) { k in
                HStack(spacing: 6) {
                    Circle().fill(Color(hex: store.legendColor(k))).frame(width: 12, height: 12)
                    Text(store.legendLabel(k)).font(.system(size: 12)).foregroundColor(pal.text).lineLimit(1)
                }
            }
        }
    }
}

struct MarkSheet: View {
    @EnvironmentObject var store: Store
    @Environment(\.pal) var pal
    let date: Date
    let onPick: (DayMark?) -> Void

    private func options() -> [(LegendItem, DayMark)] {
        var out: [(LegendItem, DayMark)] = []
        out.append((LegendItem(key: "full", label: store.legendLabel("full"), color: store.legendColor("full"), code: "1"), .full))
        out.append((LegendItem(key: "half", label: store.legendLabel("half"), color: store.legendColor("half"), code: "½"), .half))
        out.append((LegendItem(key: "leave", label: store.legendLabel("leave"), color: store.legendColor("leave"), code: "P"), .leave))
        out.append((LegendItem(key: "absent", label: store.legendLabel("absent"), color: store.legendColor("absent"), code: "O"), .absent))
        for c in store.customLegend() { out.append((c, .custom(c.key))) }
        return out
    }

    var body: some View {
        let opts = options()
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                Text("\(WEEKDAYS[date.dow - 1]), \(fmtDate(date))")
                    .font(.title3.bold()).foregroundColor(pal.text)
                Text("Chọn trạng thái công").font(.footnote).foregroundColor(pal.muted)
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                    ForEach(0..<opts.count, id: \.self) { i in
                        let item = opts[i].0
                        let mark = opts[i].1
                        let fg: Color = isLightHex(item.color) ? Color.black.opacity(0.85) : Color.white
                        Button {
                            onPick(mark)
                        } label: {
                            HStack {
                                Text(item.code).font(.system(size: 15, weight: .heavy)).frame(width: 30)
                                Text(item.label).font(.system(size: 14, weight: .bold)).lineLimit(2)
                                Spacer(minLength: 0)
                            }
                            .padding(12)
                            .frame(maxWidth: .infinity)
                            .background(Color(hex: item.color))
                            .foregroundColor(fg)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }
                    }
                }
                Button {
                    onPick(nil)
                } label: {
                    Text(store.legendLabel("empty")).font(.system(size: 15, weight: .bold))
                        .frame(maxWidth: .infinity).padding(.vertical, 13)
                        .background(pal.card2).foregroundColor(pal.text)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
            .padding(20)
        }
        .background(pal.card.ignoresSafeArea())
    }
}
