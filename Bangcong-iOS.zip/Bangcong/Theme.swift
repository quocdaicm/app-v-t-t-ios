import SwiftUI
import UserNotifications
import LocalAuthentication

extension Color {
    init(hex: String) {
        var s = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        if s.count == 3 {
            s = s.map { "\($0)\($0)" }.joined()
        }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        let r = Double((v >> 16) & 0xFF) / 255.0
        let g = Double((v >> 8) & 0xFF) / 255.0
        let b = Double(v & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b)
    }
}

/// true nếu màu nền sáng (dùng chữ tối trên nền đó).
func isLightHex(_ hex: String) -> Bool {
    var s = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
    if s.count == 3 { s = s.map { "\($0)\($0)" }.joined() }
    var v: UInt64 = 0
    Scanner(string: s).scanHexInt64(&v)
    let r = Double((v >> 16) & 0xFF)
    let g = Double((v >> 8) & 0xFF)
    let b = Double(v & 0xFF)
    return (0.299 * r + 0.587 * g + 0.114 * b) > 150
}

struct Pal {
    var bg: Color
    var card: Color
    var card2: Color
    var text: Color
    var muted: Color
    var border: Color
    var primary: Color
    var primary2: Color
    var success: Color
    var hero: Color
    var dark: Bool

    static func make(tone: String, dark: Bool) -> Pal {
        if dark {
            return Pal(bg: Color(hex: "0D1020"), card: Color(hex: "171B30"), card2: Color(hex: "20263F"),
                       text: Color(hex: "F7F8FF"), muted: Color(hex: "B4BCDE"), border: Color(hex: "2B3254"),
                       primary: Color(hex: "6B77F8"), primary2: Color(hex: "9163F6"), success: Color(hex: "4ADE80"),
                       hero: Color(hex: "5560E8"), dark: true)
        }
        let text = Color(hex: "0E1127")
        let muted = Color(hex: "454C73")
        let ok = Color(hex: "15803D")
        switch tone {
        case "sky":
            return Pal(bg: Color(hex: "E4F0FA"), card: Color(hex: "F5FAFE"), card2: Color(hex: "DCEAF6"),
                       text: text, muted: muted, border: Color(hex: "C9DDEE"),
                       primary: Color(hex: "0B6BB5"), primary2: Color(hex: "2F55D4"), success: ok,
                       hero: Color(hex: "0B6BB5"), dark: false)
        case "mint":
            return Pal(bg: Color(hex: "E3F3EE"), card: Color(hex: "F4FBF8"), card2: Color(hex: "D9EDE6"),
                       text: text, muted: muted, border: Color(hex: "C5E0D6"),
                       primary: Color(hex: "0F7358"), primary2: Color(hex: "0B8A74"), success: ok,
                       hero: Color(hex: "0F7358"), dark: false)
        case "peach":
            return Pal(bg: Color(hex: "F7EBE4"), card: Color(hex: "FFF9F5"), card2: Color(hex: "F1E2D9"),
                       text: text, muted: Color(hex: "434A70"), border: Color(hex: "E6D3C7"),
                       primary: Color(hex: "BE4A12"), primary2: Color(hex: "C2307A"), success: ok,
                       hero: Color(hex: "BE4A12"), dark: false)
        default:
            return Pal(bg: Color(hex: "E9ECF8"), card: Color(hex: "F8F9FF"), card2: Color(hex: "E3E7F6"),
                       text: text, muted: muted, border: Color(hex: "D3D9EE"),
                       primary: Color(hex: "4338CA"), primary2: Color(hex: "6D3FD1"), success: ok,
                       hero: Color(hex: "4338CA"), dark: false)
        }
    }
}

private struct PalKey: EnvironmentKey {
    static let defaultValue: Pal = Pal.make(tone: "lavender", dark: false)
}

extension EnvironmentValues {
    var pal: Pal {
        get { self[PalKey.self] }
        set { self[PalKey.self] = newValue }
    }
}

struct CardStyle: ViewModifier {
    @Environment(\.pal) var pal
    func body(content: Content) -> some View {
        content
            .padding(14)
            .background(pal.card)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(pal.border, lineWidth: 1)
            )
    }
}

extension View {
    func card() -> some View { modifier(CardStyle()) }
}

// MARK: - Sinh trắc học & nhắc chấm công

func authenticateBiometric(_ completion: @escaping (Bool) -> Void) {
    let ctx = LAContext()
    var err: NSError?
    guard ctx.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &err) else {
        completion(false)
        return
    }
    ctx.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                       localizedReason: "Mở khoá Bảng công") { ok, _ in
        DispatchQueue.main.async { completion(ok) }
    }
}

enum Reminder {
    private static let ids = (2...6).map { "bc.remind.\($0)" }

    static func schedule(hour: Int, minute: Int) {
        let c = UNUserNotificationCenter.current()
        c.requestAuthorization(options: [.alert, .sound]) { ok, _ in
            guard ok else { return }
            c.removePendingNotificationRequests(withIdentifiers: ids)
            for wd in 2...6 {
                var dc = DateComponents()
                dc.weekday = wd
                dc.hour = hour
                dc.minute = minute
                let content = UNMutableNotificationContent()
                content.title = "Nhắc chấm công"
                content.body = "Đừng quên chấm công hôm nay."
                content.sound = .default
                let trigger = UNCalendarNotificationTrigger(dateMatching: dc, repeats: true)
                c.add(UNNotificationRequest(identifier: "bc.remind.\(wd)", content: content, trigger: trigger))
            }
        }
    }

    static func cancel() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ids)
    }
}
