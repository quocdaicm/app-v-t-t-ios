import Foundation

/// Ngày nghỉ lễ, tết theo Điều 112 Bộ luật Lao động 2019 (chuyển từ bản Kotlin).
/// Chỉ gồm ngày nghỉ theo luật; ngày nghỉ bù / hoán đổi do người dùng tự thêm.
enum VnHolidays {
    static let minYear = 2021
    static let maxYear = 2100
    private static let cultureDayFrom = 2026

    static func forYear(_ year: Int) -> [Date] {
        var out: [Date] = []
        func add(_ d: Date) {
            if !out.contains(where: { $0.key == d.key }) { out.append(d) }
        }
        add(makeDate(year, 1, 1))
        if let tet = findTet(year) {
            add(tet.plusDays(-1))
            for i in 0...3 { add(tet.plusDays(i)) }
        }
        if let hung = findHungKings(year) { add(hung) }
        add(makeDate(year, 4, 30))
        add(makeDate(year, 5, 1))
        add(makeDate(year, 9, 2))
        add(makeDate(year, 9, 1))
        if year >= cultureDayFrom { add(makeDate(year, 11, 24)) }
        return out.sorted()
    }

    private static func findTet(_ year: Int) -> Date? {
        var d = makeDate(year, 1, 15)
        let end = makeDate(year, 3, 1)
        while d <= end {
            let l = Lunar.fromSolar(d.dom, d.mon, d.yr)
            if l.day == 1 && l.month == 1 { return d }
            d = d.plusDays(1)
        }
        return nil
    }

    private static func findHungKings(_ year: Int) -> Date? {
        var d = makeDate(year, 3, 1)
        let end = makeDate(year, 5, 31)
        while d <= end {
            let l = Lunar.fromSolar(d.dom, d.mon, d.yr)
            if l.day == 10 && l.month == 3 && !l.leap { return d }
            d = d.plusDays(1)
        }
        return nil
    }
}
