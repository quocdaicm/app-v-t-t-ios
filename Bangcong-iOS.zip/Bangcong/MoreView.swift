import SwiftUI
import UniformTypeIdentifiers

struct MoreView: View {
    @EnvironmentObject var store: Store
    @Environment(\.pal) var pal
    @State private var showImporter = false
    @State private var showReset = false
    @State private var showPin = false
    @State private var message = ""
    @State private var showMessage = false
    @State private var remindTime = Date()

    var body: some View {
        NavigationStack {
            Form {
                Section("Hồ sơ") {
                    NavigationLink("Hồ sơ cá nhân") { ProfileView() }
                    Picker("Kỳ công bắt đầu ngày", selection: Binding(
                        get: { store.periodStartDay },
                        set: { store.setPeriodStart($0) }
                    )) {
                        ForEach(1...31, id: \.self) { d in Text("Ngày \(d)").tag(d) }
                    }
                    NavigationLink("Ngày lễ") { HolidaysView() }
                }

                Section("Giao diện") {
                    Picker("Chế độ", selection: Binding(
                        get: { store.theme },
                        set: { store.setTheme($0) }
                    )) {
                        Text("Hệ thống").tag("system")
                        Text("Sáng").tag("light")
                        Text("Tối").tag("dark")
                    }
                    Picker("Tông màu", selection: Binding(
                        get: { store.tone },
                        set: { store.setTone($0) }
                    )) {
                        Text("Tím").tag("lavender")
                        Text("Xanh trời").tag("sky")
                        Text("Xanh mint").tag("mint")
                        Text("Đào").tag("peach")
                    }
                }

                Section(header: Text("Nhắc chấm công"), footer: Text("Nhắc từ thứ 2 đến thứ 6.")) {
                    Toggle("Bật nhắc chấm công", isOn: Binding(
                        get: { store.reminderOn },
                        set: { store.setReminder(on: $0, hour: store.reminderHour, minute: store.reminderMinute) }
                    ))
                    if store.reminderOn {
                        DatePicker("Giờ nhắc", selection: $remindTime, displayedComponents: .hourAndMinute)
                            .onChange(of: remindTime) { t in
                                store.setReminder(on: true,
                                                  hour: cal.component(.hour, from: t),
                                                  minute: cal.component(.minute, from: t))
                            }
                    }
                }

                Section("Bảo mật") {
                    if store.hasPin {
                        Toggle("Mở khoá bằng Face ID / Touch ID", isOn: Binding(
                            get: { store.biometricOn },
                            set: { store.setBiometric($0) }
                        ))
                        Button("Đổi mã PIN") { showPin = true }
                        Button("Tắt mã PIN", role: .destructive) { store.setPin("") }
                    } else {
                        Button("Đặt mã PIN") { showPin = true }
                    }
                }

                Section(header: Text("Dữ liệu"), footer: Text("File sao lưu dùng chung định dạng với bản Android: xuất từ Android rồi nhập vào đây được.")) {
                    ShareLink(item: store.exportFileURL()) {
                        Label("Xuất / sao lưu JSON", systemImage: "square.and.arrow.up")
                    }
                    Button {
                        showImporter = true
                    } label: {
                        Label("Nhập từ file JSON", systemImage: "square.and.arrow.down")
                    }
                    Button(role: .destructive) {
                        showReset = true
                    } label: {
                        Label("Xoá toàn bộ dữ liệu", systemImage: "trash")
                    }
                }

                Section {
                    Text("Bảng công cá nhân · bản iOS 1.0").font(.footnote).foregroundColor(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(pal.bg.ignoresSafeArea())
            .navigationTitle("Thêm")
            .onAppear {
                remindTime = cal.date(bySettingHour: store.reminderHour, minute: store.reminderMinute, second: 0, of: Date()) ?? Date()
            }
        }
        .sheet(isPresented: $showPin) { PinSetupView() }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [UTType.json]) { result in
            switch result {
            case .success(let url):
                let ok = url.startAccessingSecurityScopedResource()
                defer { if ok { url.stopAccessingSecurityScopedResource() } }
                if let data = try? Data(contentsOf: url), data.count < 8_000_000, store.importJSON(data) {
                    message = "Đã nhập dữ liệu."
                } else {
                    message = "File không hợp lệ hoặc quá lớn."
                }
            case .failure:
                message = "Không đọc được file."
            }
            showMessage = true
        }
        .confirmationDialog("Xoá toàn bộ dữ liệu?", isPresented: $showReset, titleVisibility: .visible) {
            Button("Xoá hết", role: .destructive) { store.resetAll() }
            Button("Huỷ", role: .cancel) {}
        } message: {
            Text("Chấm công, tăng ca, cài đặt lương và mã PIN sẽ bị xoá và không thể khôi phục.")
        }
        .alert(message, isPresented: $showMessage) { Button("OK", role: .cancel) {} }
    }
}

struct ProfileView: View {
    @EnvironmentObject var store: Store
    @State private var name = ""
    @State private var code = ""
    @State private var position = ""
    @State private var department = ""
    @State private var company = ""
    @State private var loaded = false

    var body: some View {
        Form {
            Section("Tên ứng dụng") {
                TextField("Bảng công", text: $company)
            }
            Section("Thông tin") {
                TextField("Họ và tên", text: $name)
                TextField("Mã nhân viên", text: $code)
                TextField("Chức vụ", text: $position)
                TextField("Phòng ban", text: $department)
            }
        }
        .navigationTitle("Hồ sơ")
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Lưu") {
                    store.saveProfile(name: name, code: code, position: position, department: department)
                    store.setCompany(company)
                }
            }
        }
        .onAppear {
            if !loaded {
                name = store.profileName
                code = store.profileCode
                position = store.profilePosition
                department = store.profileDepartment
                company = store.company == "Bảng công" ? "" : store.company
                loaded = true
            }
        }
    }
}

struct HolidaysView: View {
    @EnvironmentObject var store: Store
    @State private var year = Date().yr
    @State private var newDate = Date().dayStart
    @State private var info = ""

    var body: some View {
        let list = store.holidays()
        List {
            Section(header: Text("Nạp ngày lễ Việt Nam"), footer: Text(info.isEmpty ? "Chỉ gồm ngày nghỉ theo luật; ngày nghỉ bù thì tự thêm." : info)) {
                Stepper("Năm \(year)", value: $year, in: VnHolidays.minYear...VnHolidays.maxYear)
                Button("Nạp ngày lễ năm \(year)") {
                    let n = store.addHolidays(VnHolidays.forYear(year))
                    info = n > 0 ? "Đã thêm \(n) ngày." : "Các ngày lễ năm này đã có."
                }
            }
            Section("Thêm ngày lễ riêng") {
                DatePicker("Ngày", selection: $newDate, displayedComponents: .date)
                Button("Thêm") { _ = store.addHolidays([newDate.dayStart]) }
            }
            Section("Danh sách (\(list.count))") {
                ForEach(list, id: \.key) { d in
                    Text("\(SHORT[d.dow - 1]) \(fmtDate(d))")
                        .swipeActions {
                            Button(role: .destructive) { store.removeHoliday(d) } label: { Label("Xoá", systemImage: "trash") }
                        }
                }
            }
        }
        .navigationTitle("Ngày lễ")
    }
}

struct PinSetupView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @State private var pin = ""
    @State private var again = ""

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Mã PIN 4–8 chữ số")) {
                    SecureField("PIN", text: $pin).keyboardType(.numberPad)
                    SecureField("Nhập lại PIN", text: $again).keyboardType(.numberPad)
                }
                if !again.isEmpty && pin != again {
                    Text("Hai mã PIN chưa khớp").foregroundColor(.red)
                }
            }
            .navigationTitle("Đặt mã PIN")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") {
                        store.setPin(pin)
                        dismiss()
                    }
                    .disabled(pin.count < 4 || pin.count > 8 || pin != again || !pin.allSatisfy { $0.isNumber })
                }
            }
        }
    }
}
