import SwiftUI

@main
struct BangcongApp: App {
    @StateObject private var store = Store()

    private var forcedScheme: ColorScheme? {
        if store.theme == "dark" { return .dark }
        if store.theme == "light" { return .light }
        return nil
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .preferredColorScheme(forcedScheme)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: Store
    @Environment(\.colorScheme) var scheme
    @Environment(\.scenePhase) var phase
    @State private var backgroundAt: Date?
    @State private var tab = 0

    private var dark: Bool {
        if store.theme == "dark" { return true }
        if store.theme == "light" { return false }
        return scheme == .dark
    }

    var body: some View {
        let pal = Pal.make(tone: store.tone, dark: dark)
        ZStack {
            if store.pinRequired {
                LockView()
            } else {
                MainTabs(tab: $tab)
            }
            if phase != .active && store.hasPin {
                pal.bg.ignoresSafeArea()
            }
        }
        .environment(\.pal, pal)
        .tint(pal.primary)
        .onChange(of: phase) { p in
            if p == .background {
                backgroundAt = Date()
            } else if p == .active {
                if let t = backgroundAt, Date().timeIntervalSince(t) > 60 { store.lock() }
                backgroundAt = nil
            }
        }
    }
}

struct MainTabs: View {
    @Binding var tab: Int

    var body: some View {
        TabView(selection: $tab) {
            HomeView(tab: $tab)
                .tabItem { Label("Tổng quan", systemImage: "calendar") }
                .tag(0)
            OtView()
                .tabItem { Label("Tăng ca", systemImage: "clock") }
                .tag(1)
            PayrollView()
                .tabItem { Label("Lương", systemImage: "banknote") }
                .tag(2)
            MoreView()
                .tabItem { Label("Thêm", systemImage: "ellipsis.circle") }
                .tag(3)
        }
    }
}

struct LockView: View {
    @EnvironmentObject var store: Store
    @Environment(\.pal) var pal
    @State private var pin = ""
    @State private var error = ""
    @State private var wait = 0

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "lock.fill").font(.system(size: 44)).foregroundColor(pal.primary)
            Text(store.company).font(.title2.bold()).foregroundColor(pal.text)
            Text("Nhập mã PIN để mở").foregroundColor(pal.muted)
            SecureField("PIN", text: $pin)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.center)
                .font(.title2)
                .padding(12)
                .background(pal.card)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .frame(maxWidth: 220)
            if wait > 0 {
                Text("Thử lại sau \(wait) giây").foregroundColor(.red)
            } else if !error.isEmpty {
                Text(error).foregroundColor(.red)
            }
            Button("Mở khoá") { submit() }
                .buttonStyle(.borderedProminent)
                .disabled(pin.count < 4 || wait > 0)
            if store.biometricOn {
                Button("Dùng Face ID / Touch ID") { bio() }
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(pal.bg.ignoresSafeArea())
        .onAppear {
            refreshWait()
            if store.biometricOn { bio() }
        }
        .onReceive(Timer.publish(every: 1, on: .main, in: .common).autoconnect()) { _ in refreshWait() }
    }

    private func refreshWait() { wait = Int(store.lockoutRemaining().rounded(.up)) }

    private func submit() {
        if store.tryUnlock(pin) {
            pin = ""
        } else {
            error = "PIN không đúng"
            pin = ""
            refreshWait()
        }
    }

    private func bio() {
        authenticateBiometric { ok in
            if ok { store.unlockWithBiometric() }
        }
    }
}
