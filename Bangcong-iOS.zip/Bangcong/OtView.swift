import SwiftUI

private let hmFmt: DateFormatter = {
    let f = DateFormatter()
    f.locale = Locale(identifier: "en_US_POSIX")
    f.dateFormat = "HH:mm"
    return f
}()

private func timeDate(_ s: String, fallbackHour: Int) -> Date {
    let p = s.split(separator: ":")
    var h = fallbackHour
    var m = 0
    if p.count >= 2, let hh = Int(p[0]), let mm = Int(p[1]) { h = hh; m = mm }
    return cal.date(bySettingHour: h, minute: m, second: 0, of: Date()) ?? Date()
}

private func hoursBetween(_ a: Date, _ b: Date) -> Double {
    let am = cal.component(.hour, from: a) * 60 + cal.component(.minute, from: a)
    let bm = cal.component(.hour, from: b) * 60 + cal.component(.minute, from: b)
    var diff = bm - am
    if diff <= 0 { diff += 24 * 60 }
    return (Double(diff) / 60.0 * 100).rounded() / 100
}

struct OtDraft: Identifiable {
    var id: Int64
    var isNew: Bool
    var date: Date
    var from: Date
    var to: Date
    var reason: String
}

struct OtView: View {
    @EnvironmentObject var store: Store
    @Environment(\.pal) var pal
    @State private var anchor = Date().dayStart
    @State private var draft: OtDraft?

    private func shift(_ delta: Int) {
        anchor = store.shiftPeriod(store.periodOf(anchor), delta).start
    }

    private func newDraft(_ p: Period) -> OtDraft {
        let t = Date().dayStart
        let d = p.contains(t) ? t : p.start
        return OtDraft(id: 0, isNew: true, date: d,
                       from: timeDate("17:30", fallbackHour: 17), to: timeDate("19:30", fallbackHour: 19), reason: "")
    }

    private func tag(_ d: Date) -> String {
        if store.isHoliday(d) { return "Ngày lễ" }
        if store.isOffDay(d) { return "Ngày nghỉ" }
        return "Ngày thường"
    }

    var body: some View {
        let p = store.periodOf(anchor)
        let entries = store.otEntries(p).sorted { a, b in
            a.date != b.date ? a.date > b.date : a.id > b.id
        }
        let total = entries.reduce(0.0) { $0 + $1.hours }
        VStack(spacing: 10) {
            PeriodNav(title: "\(fmtDate(p.start)) → \(fmtDate(p.end))", onPrev: { shift(-1) }, onNext: { shift(1) })
                .card()
            HStack {
                Text("Tổng giờ tăng ca").foregroundColor(pal.muted)
                Spacer()
                Text("\(fmtNum(total)) giờ").font(.title3.bold()).foregroundColor(pal.primary)
            }
            .card()
            if entries.isEmpty {
                Spacer()
                Text("Chưa có giờ tăng ca trong kỳ này").foregroundColor(pal.muted)
                Spacer()
            } else {
                List {
                    ForEach(entries) { e in
                        Button {
                            draft = OtDraft(id: e.id, isNew: false, date: e.date,
                                            from: timeDate(e.from, fallbackHour: 17),
                                            to: timeDate(e.to, fallbackHour: 19), reason: e.reason)
                        } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("\(SHORT[e.date.dow - 1]) \(z2(e.date.dom))/\(z2(e.date.mon)) · \(tag(e.date))")
                                        .font(.system(size: 14, weight: .bold)).foregroundColor(pal.text)
                                    Text("\(e.from) – \(e.to)" + (e.reason.isEmpty ? "" : " · \(e.reason)"))
                                        .font(.footnote).foregroundColor(pal.muted)
                                }
                                Spacer()
                                Text("\(fmtNum(e.hours)) giờ").font(.system(size: 15, weight: .heavy)).foregroundColor(pal.primary)
                            }
                        }
                        .listRowBackground(pal.card)
                        .swipeActions {
                            Button(role: .destructive) { store.deleteOt(e.id) } label: { Label("Xoá", systemImage: "trash") }
                        }
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
            }
            Button {
                draft = newDraft(p)
            } label: {
                Label("Thêm giờ tăng ca", systemImage: "plus")
                    .font(.system(size: 16, weight: .bold))
                    .frame(maxWidth: .infinity).padding(.vertical, 14)
                    .background(pal.primary).foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
        }
        .padding(16)
        .background(pal.bg.ignoresSafeArea())
        .sheet(item: $draft) { d in
            OtForm(draft: d) { saved in
                let f = hmFmt.string(from: saved.from)
                let t = hmFmt.string(from: saved.to)
                let h = hoursBetween(saved.from, saved.to)
                if saved.isNew {
                    store.addOt(date: saved.date, from: f, to: t, hours: h, reason: saved.reason)
                } else {
                    store.updateOt(id: saved.id, date: saved.date, from: f, to: t, hours: h, reason: saved.reason)
                }
                draft = nil
            } onCancel: {
                draft = nil
            }
            .presentationDetents([.medium, .large])
        }
    }
}

struct OtForm: View {
    @Environment(\.pal) var pal
    @State var draft: OtDraft
    let onSave: (OtDraft) -> Void
    let onCancel: () -> Void

    var body: some View {
        NavigationStack {
            Form {
                DatePicker("Ngày", selection: $draft.date, displayedComponents: .date)
                DatePicker("Giờ vào", selection: $draft.from, displayedComponents: .hourAndMinute)
                DatePicker("Giờ ra", selection: $draft.to, displayedComponents: .hourAndMinute)
                HStack {
                    Text("Số giờ")
                    Spacer()
                    Text("\(fmtNum(hoursBetween(draft.from, draft.to))) giờ").bold()
                }
                TextField("Lý do (không bắt buộc)", text: $draft.reason)
            }
            .navigationTitle(draft.isNew ? "Thêm tăng ca" : "Sửa tăng ca")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Huỷ", action: onCancel) }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") {
                        var d = draft
                        d.date = d.date.dayStart
                        onSave(d)
                    }
                }
            }
        }
    }
}
