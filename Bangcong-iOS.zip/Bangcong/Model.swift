import Foundation

let cal: Calendar = {
    var c = Calendar(identifier: .gregorian)
    c.firstWeekday = 2
    return c
}()

enum DateKey {
    static let fmt: DateFormatter = {
        let f = DateFormatter()
        f.calendar = Calendar(identifier: .gregorian)
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = TimeZone.current
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()
}

extension Date {
    var dayStart: Date { cal.startOfDay(for: self) }
    var key: String { DateKey.fmt.string(from: self) }
    /// 1 = Thứ 2 ... 7 = Chủ nhật
    var dow: Int { (cal.component(.weekday, from: self) + 5) % 7 + 1 }
    var dom: Int { cal.component(.day, from: self) }
    var mon: Int { cal.component(.month, from: self) }
    var yr: Int { cal.component(.year, from: self) }
    func plusDays(_ n: Int) -> Date { cal.date(byAdding: .day, value: n, to: self) ?? self }
}

func makeDate(_ y: Int, _ m: Int, _ d: Int) -> Date {
    var c = DateComponents()
    c.year = y; c.month = m; c.day = d
    return cal.date(from: c) ?? Date().dayStart
}

func parseDate(_ s: String) -> Date? { DateKey.fmt.date(from: s) }

func daysIn(_ y: Int, _ m: Int) -> Int {
    cal.range(of: .day, in: .month, for: makeDate(y, m, 1))?.count ?? 30
}

func addMonths(_ y: Int, _ m: Int, _ delta: Int) -> (Int, Int) {
    let t = y * 12 + (m - 1) + delta
    return (t / 12, t % 12 + 1)
}

let WEEKDAYS = ["Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy", "Chủ nhật"]
let SHORT = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]

func z2(_ n: Int) -> String { n < 10 ? "0\(n)" : "\(n)" }
func fmtDate(_ d: Date) -> String { "\(z2(d.dom))/\(z2(d.mon))/\(d.yr)" }

func fmtNum(_ x: Double) -> String {
    if x == x.rounded() { return String(Int(x)) }
    var t = String(format: "%.2f", x)
    while t.hasSuffix("0") { t.removeLast() }
    if t.hasSuffix(".") { t.removeLast() }
    return t.replacingOccurrences(of: ".", with: ",")
}

func fmtMoney(_ v: Int64) -> String {
    let neg = v < 0
    let s = String(v < 0 ? -v : v)
    var out = ""
    for (i, ch) in s.reversed().enumerated() {
        if i > 0 && i % 3 == 0 { out.append(".") }
        out.append(ch)
    }
    return (neg ? "-" : "") + String(out.reversed()) + " ₫"
}

/// Làm tròn nửa lên, giống Math.round của Kotlin.
func rnd(_ x: Double) -> Int64 { Int64((x + 0.5).rounded(.down)) }

struct Period {
    let start: Date
    let end: Date
    var days: [Date] {
        var out: [Date] = []
        var d = start
        var guardCount = 0
        while d <= end && guardCount < 400 {
            out.append(d)
            d = d.plusDays(1)
            guardCount += 1
        }
        return out
    }
    func contains(_ d: Date) -> Bool { d >= start && d <= end }
    /// Tháng đại diện của kỳ (giống bản Android: lấy ngày giữa kỳ).
    var monthOfPeriod: Int { start.plusDays(15).mon }
}

struct Summary {
    var work: Double
    var ot: Double
    var leaveP: Int
    var absentO: Int
}

struct OtEntry: Identifiable {
    let id: Int64
    let date: Date
    let from: String
    let to: String
    let hours: Double
    let reason: String
}

struct ExtraEntry: Identifiable {
    let id: Int64
    let date: Date
    let amount: Int64
    let note: String
}

struct LegendItem: Identifiable {
    var id: String { key }
    let key: String
    let label: String
    let color: String
    let code: String
}

enum DayMark: Equatable {
    case full, half, leave, absent
    case custom(String)

    var json: Any {
        switch self {
        case .full: return 1.0
        case .half: return 0.5
        case .leave: return "P"
        case .absent: return "O"
        case .custom(let k): return k
        }
    }
    var work: Double {
        switch self {
        case .full: return 1.0
        case .half: return 0.5
        default: return 0.0
        }
    }
    var legendKey: String {
        switch self {
        case .full: return "full"
        case .half: return "half"
        case .leave: return "leave"
        case .absent: return "absent"
        case .custom(let k): return k
        }
    }
}

struct PayrollSettings {
    var monthly: Int64 = 0
    var stdDays: Double = 23
    var allowance: Int64 = 0
    var paidLeave = true
    var rateNormal = 150
    var rateWeekend = 200
    var rateHoliday = 300
    var satWorkMask = 0
    var satDayValue = 1.0
    var rateSaturday = 200
    var autoHoliday = true
    var sunWorkMask = 0
    var sunDayValue = 1.0
    var restByHours = false
    var hoursPerDay = 8.0
    var stdAuto = false
    var otBaseMode = 0
    var basic: Int64 = 0
    var otBaseAmount: Int64 = 0
    var otStdDays = 0.0
    var insOn = false
    var insBase: Int64 = 0
    var insPct = 10.5

    var otBase: Int64 {
        switch otBaseMode {
        case 1: return monthly + allowance
        case 2: return otBaseAmount > 0 ? otBaseAmount : monthly
        default: return basic > 0 ? basic : monthly
        }
    }
}

struct Payroll {
    var configured = false
    var workDays = 0.0
    var dayRate = 0.0
    var hourRate = 0.0
    var base: Int64 = 0
    var hoursNormal = 0.0
    var hoursWeekend = 0.0
    var hoursHoliday = 0.0
    var otNormal: Int64 = 0
    var otWeekend: Int64 = 0
    var otHoliday: Int64 = 0
    var allowance: Int64 = 0
    var total: Int64 = 0
    var holidayDays = 0.0
    var holidayPay: Int64 = 0
    var hoursNight = 0.0
    var otNight: Int64 = 0
    var hoursSaturday = 0.0
    var otSaturday: Int64 = 0
    var restSatDays = 0.0
    var restSunDays = 0.0
    var restSatPay: Int64 = 0
    var restSunPay: Int64 = 0
    var stdUsed = 0.0
    var otDayRate = 0.0
    var insurance: Int64 = 0
    var net: Int64 = 0
    var extra: Int64 = 0
}

func saturdayOrdinal(_ d: Date) -> Int { (d.dom - 1) / 7 + 1 }

func isSatWorkday(_ d: Date, _ mask: Int) -> Bool {
    d.dow == 6 && ((mask >> (saturdayOrdinal(d) - 1)) & 1) == 1
}

func isSunWorkday(_ d: Date, _ mask: Int) -> Bool {
    d.dow == 7 && ((mask >> (saturdayOrdinal(d) - 1)) & 1) == 1
}

func isRestDay(_ d: Date, _ s: PayrollSettings) -> Bool {
    (d.dow == 7 && !isSunWorkday(d, s.sunWorkMask)) || (d.dow == 6 && !isSatWorkday(d, s.satWorkMask))
}

/// Số giờ nằm trong khung đêm 22:00–06:00 của ca from–to (HH:mm, được phép qua nửa đêm).
func nightHoursOf(_ from: String, _ to: String) -> Double {
    func mins(_ s: String) -> Int? {
        let p = s.split(separator: ":")
        guard p.count >= 2, let h = Int(p[0].trimmingCharacters(in: .whitespaces)),
              let m = Int(p[1].trimmingCharacters(in: .whitespaces)) else { return nil }
        return h * 60 + m
    }
    guard let a = mins(from), let b = mins(to) else { return 0 }
    var diff = b - a
    if diff <= 0 { diff += 24 * 60 }
    var night = 0
    for i in 0..<diff {
        let t = (a + i) % (24 * 60)
        if t >= 22 * 60 || t < 6 * 60 { night += 1 }
    }
    return Double(night) / 60.0
}
