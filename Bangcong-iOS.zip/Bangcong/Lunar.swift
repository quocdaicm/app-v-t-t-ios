import Foundation

/// Đổi Dương lịch sang Âm lịch Việt Nam (thuật toán Hồ Ngọc Đức), chuyển từ bản Kotlin.
enum Lunar {
    struct LDate {
        let day: Int
        let month: Int
        let year: Int
        let leap: Bool
    }

    private static func fl(_ d: Double) -> Int { Int(d.rounded(.down)) }

    private static func jdFromDate(_ dd: Int, _ mm: Int, _ yy: Int) -> Int {
        let a = fl(Double(14 - mm) / 12.0)
        let y = yy + 4800 - a
        let m = mm + 12 * a - 3
        let p1 = fl(Double(153 * m + 2) / 5.0)
        let p2 = fl(Double(y) / 4.0)
        let p3 = fl(Double(y) / 100.0)
        let p4 = fl(Double(y) / 400.0)
        var jd = dd + p1 + 365 * y + p2 - p3 + p4 - 32045
        if jd < 2299161 {
            jd = dd + p1 + 365 * y + p2 - 32083
        }
        return jd
    }

    private static func newMoon(_ k: Int) -> Double {
        let kd = Double(k)
        let t = kd / 1236.85
        let t2 = t * t
        let t3 = t2 * t
        let dr = Double.pi / 180.0
        var jd1 = 2415020.75933 + 29.53058868 * kd + 0.0001178 * t2 - 0.000000155 * t3
        jd1 += 0.00033 * sin((166.56 + 132.87 * t - 0.009173 * t2) * dr)
        let m = 359.2242 + 29.10535608 * kd - 0.0000333 * t2 - 0.00000347 * t3
        let mpr = 306.0253 + 385.81691806 * kd + 0.0107306 * t2 + 0.00001236 * t3
        let f = 21.2964 + 390.67050646 * kd - 0.0016528 * t2 - 0.00000239 * t3
        var c1 = (0.1734 - 0.000393 * t) * sin(m * dr) + 0.0021 * sin(2 * dr * m)
        c1 = c1 - 0.4068 * sin(mpr * dr) + 0.0161 * sin(dr * 2 * mpr)
        c1 = c1 - 0.0004 * sin(dr * 3 * mpr)
        c1 = c1 + 0.0104 * sin(dr * 2 * f) - 0.0051 * sin(dr * (m + mpr))
        c1 = c1 - 0.0074 * sin(dr * (m - mpr)) + 0.0004 * sin(dr * (2 * f + m))
        c1 = c1 - 0.0004 * sin(dr * (2 * f - m)) - 0.0006 * sin(dr * (2 * f + mpr))
        c1 = c1 + 0.0010 * sin(dr * (2 * f - mpr)) + 0.0005 * sin(dr * (2 * mpr + m))
        var deltat: Double
        if t < -11 {
            deltat = 0.001 + 0.000839 * t + 0.0002261 * t2
            deltat = deltat - 0.00000845 * t3 - 0.000000081 * t * t3
        } else {
            deltat = -0.000278 + 0.000265 * t + 0.000262 * t2
        }
        return jd1 + c1 - deltat
    }

    private static func sunLongitude(_ jdn: Double) -> Double {
        let t = (jdn - 2451545.0) / 36525.0
        let t2 = t * t
        let dr = Double.pi / 180.0
        let m = 357.52910 + 35999.05030 * t - 0.0001559 * t2 - 0.00000048 * t * t2
        let l0 = 280.46645 + 36000.76983 * t + 0.0003032 * t2
        var dl = (1.914600 - 0.004817 * t - 0.000014 * t2) * sin(dr * m)
        dl = dl + (0.019993 - 0.000101 * t) * sin(dr * 2 * m) + 0.000290 * sin(dr * 3 * m)
        var l = (l0 + dl) * dr
        let twoPi = Double.pi * 2
        l -= twoPi * Double(fl(l / twoPi))
        return l
    }

    private static func sunLong(_ dayNumber: Int, _ tz: Int) -> Int {
        fl(sunLongitude(Double(dayNumber) - 0.5 - Double(tz) / 24.0) / Double.pi * 6)
    }

    private static func newMoonDay(_ k: Int, _ tz: Int) -> Int {
        fl(newMoon(k) + 0.5 + Double(tz) / 24.0)
    }

    private static func lunarMonth11(_ yy: Int, _ tz: Int) -> Int {
        let off = jdFromDate(31, 12, yy) - 2415021
        let k = fl(Double(off) / 29.530588853)
        var nm = newMoonDay(k, tz)
        if sunLong(nm, tz) >= 9 { nm = newMoonDay(k - 1, tz) }
        return nm
    }

    private static func leapMonthOffset(_ a11: Int, _ tz: Int) -> Int {
        let k = fl((Double(a11) - 2415021.076998695) / 29.530588853 + 0.5)
        var last = 0
        var i = 1
        var arc = sunLong(newMoonDay(k + i, tz), tz)
        repeat {
            last = arc
            i += 1
            arc = sunLong(newMoonDay(k + i, tz), tz)
        } while arc != last && i < 14
        return i - 1
    }

    static func fromSolar(_ dd: Int, _ mm: Int, _ yy: Int, tz: Int = 7) -> LDate {
        let dayNumber = jdFromDate(dd, mm, yy)
        let k = fl((Double(dayNumber) - 2415021.076998695) / 29.530588853)
        var monthStart = newMoonDay(k + 1, tz)
        if monthStart > dayNumber { monthStart = newMoonDay(k, tz) }
        var a11 = lunarMonth11(yy, tz)
        var b11 = a11
        var lunarYear = 0
        if a11 >= monthStart {
            lunarYear = yy
            a11 = lunarMonth11(yy - 1, tz)
        } else {
            lunarYear = yy + 1
            b11 = lunarMonth11(yy + 1, tz)
        }
        let lunarDay = dayNumber - monthStart + 1
        let diff = fl(Double(monthStart - a11) / 29.0)
        var leap = false
        var lunarMonth = diff + 11
        if b11 - a11 > 365 {
            let leapDiff = leapMonthOffset(a11, tz)
            if diff >= leapDiff {
                lunarMonth = diff + 10
                if diff == leapDiff { leap = true }
            }
        }
        if lunarMonth > 12 { lunarMonth -= 12 }
        if lunarMonth >= 11 && diff < 4 { lunarYear -= 1 }
        return LDate(day: lunarDay, month: lunarMonth, year: lunarYear, leap: leap)
    }
}
