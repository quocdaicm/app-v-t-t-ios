import SwiftUI

struct PayRow: View {
    @Environment(\.pal) var pal
    let label: String
    let detail: String
    let amount: String
    var bold = false

    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 2) {
                Text(label).font(.system(size: 14, weight: bold ? .heavy : .semibold)).foregroundColor(pal.text)
                if !detail.isEmpty {
                    Text(detail).font(.system(size: 12)).foregroundColor(pal.muted)
                }
            }
            Spacer()
            Text(amount).font(.system(size: 14, weight: bold ? .heavy : .bold)).foregroundColor(pal.text)
        }
    }
}

struct PayrollView: View {
    @EnvironmentObject var store: Store
    @Environment(\.pal) var pal
    @State var anchor = Date().dayStart
    @State var showSettings = false
    @State var showExtra = false

    private func shift(_ delta: Int) {
        anchor = store.shiftPeriod(store.periodOf(anchor), delta).start
    }

    var body: some View {
        let p = store.periodOf(anchor)
        let r = store.payroll(p)
        let extras = store.extraEntries(p)
        ScrollView {
            VStack(spacing: 12) {
                PeriodNav(title: "\(fmtDate(p.start)) → \(fmtDate(p.end))", onPrev: { shift(-1) }, onNext: { shift(1) })
                    .card()
                heroCard(r)
                if r.configured {
                    breakdownCard(r)
                } else {
                    Text("Bạn chưa nhập lương tháng. Bấm \"Cài đặt lương\" để nhập lương và hệ số tăng ca.")
                        .foregroundColor(pal.muted).card()
                }
                extrasCard(extras)
                Button {
                    showSettings = true
                } label: {
                    Label("Cài đặt lương", systemImage: "slider.horizontal.3")
                        .font(.system(size: 16, weight: .bold))
                        .frame(maxWidth: .infinity).padding(.vertical, 14)
                        .background(pal.primary).foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
                Text("Lương tạm tính, chưa gồm thuế TNCN. Số liệu mang tính tham khảo.")
                    .font(.caption).foregroundColor(pal.muted).multilineTextAlignment(.center)
            }
            .padding(16)
        }
        .background(pal.bg.ignoresSafeArea())
        .sheet(isPresented: $showSettings) { PayrollSettingsView(initial: store.payrollSettings) }
        .sheet(isPresented: $showExtra) {
            ExtraForm(period: p) { date, amount, note in
                store.addExtra(date: date, amount: amount, note: note)
                showExtra = false
            } onCancel: { showExtra = false }
            .presentationDetents([.medium])
        }
    }

    private func heroCard(_ r: Payroll) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(r.insurance > 0 ? "Thực nhận (sau bảo hiểm)" : "Lương tạm tính")
                .font(.caption.bold()).foregroundColor(.white.opacity(0.85))
            Text(r.configured ? fmtMoney(r.net) : "—").font(.system(size: 30, weight: .heavy)).foregroundColor(.white)
            if r.configured {
                Text("\(fmtNum(r.workDays)) công × \(fmtMoney(rnd(r.dayRate))) / công (công chuẩn \(fmtNum(r.stdUsed)))")
                    .font(.footnote).foregroundColor(.white.opacity(0.85))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(LinearGradient(colors: [pal.hero, pal.primary2], startPoint: .topLeading, endPoint: .bottomTrailing))
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    private func breakdownCard(_ r: Payroll) -> some View {
        let s = store.payrollSettings
        return VStack(spacing: 12) {
            PayRow(label: "Lương theo công", detail: "\(fmtNum(r.workDays)) công", amount: fmtMoney(r.base))
            if r.holidayPay > 0 {
                PayRow(label: "Lương ngày lễ", detail: "\(fmtNum(r.holidayDays)) công", amount: fmtMoney(r.holidayPay))
            }
            if r.restSatPay > 0 {
                PayRow(label: "Công thứ 7 nghỉ", detail: "\(fmtNum(r.restSatDays)) công × \(s.rateSaturday)%", amount: fmtMoney(r.restSatPay))
            }
            if r.restSunPay > 0 {
                PayRow(label: "Công Chủ nhật nghỉ", detail: "\(fmtNum(r.restSunDays)) công × \(s.rateWeekend)%", amount: fmtMoney(r.restSunPay))
            }
            if r.otNormal > 0 {
                PayRow(label: "OT ngày thường", detail: "\(fmtNum(r.hoursNormal)) giờ × \(s.rateNormal)%", amount: fmtMoney(r.otNormal))
            }
            if r.otSaturday > 0 {
                PayRow(label: "OT thứ 7 nghỉ", detail: "\(fmtNum(r.hoursSaturday)) giờ × \(s.rateSaturday)%", amount: fmtMoney(r.otSaturday))
            }
            if r.otWeekend > 0 {
                PayRow(label: "OT ngày nghỉ", detail: "\(fmtNum(r.hoursWeekend)) giờ × \(s.rateWeekend)%", amount: fmtMoney(r.otWeekend))
            }
            if r.otHoliday > 0 {
                PayRow(label: "OT ngày lễ", detail: "\(fmtNum(r.hoursHoliday)) giờ × \(s.rateHoliday)%", amount: fmtMoney(r.otHoliday))
            }
            if r.otNight > 0 {
                PayRow(label: "Phụ trội OT đêm", detail: "\(fmtNum(r.hoursNight)) giờ (22h–6h)", amount: fmtMoney(r.otNight))
            }
            if r.allowance > 0 {
                PayRow(label: "Phụ cấp", detail: "", amount: fmtMoney(r.allowance))
            }
            if r.extra != 0 {
                PayRow(label: "Thưởng / phụ cấp thêm", detail: "", amount: fmtMoney(r.extra))
            }
            Divider()
            PayRow(label: "Tổng thu nhập", detail: "", amount: fmtMoney(r.total), bold: true)
            if r.insurance > 0 {
                PayRow(label: "Bảo hiểm (\(fmtNum(s.insPct))%)", detail: "", amount: "-" + fmtMoney(r.insurance))
                PayRow(label: "Thực nhận", detail: "", amount: fmtMoney(r.net), bold: true)
            }
        }
        .card()
    }

    private func extrasCard(_ extras: [ExtraEntry]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Thưởng / phụ cấp thêm").font(.system(size: 15, weight: .bold)).foregroundColor(pal.text)
                Spacer()
                Button { showExtra = true } label: { Image(systemName: "plus.circle.fill").font(.title3) }
            }
            if extras.isEmpty {
                Text("Chưa có khoản nào trong kỳ").font(.footnote).foregroundColor(pal.muted)
            }
            ForEach(extras) { e in
                HStack {
                    VStack(alignment: .leading) {
                        Text(e.note.isEmpty ? "Khoản thêm" : e.note).font(.system(size: 14, weight: .semibold)).foregroundColor(pal.text)
                        Text(fmtDate(e.date)).font(.caption).foregroundColor(pal.muted)
                    }
                    Spacer()
                    Text(fmtMoney(e.amount)).font(.system(size: 14, weight: .bold)).foregroundColor(pal.text)
                    Button(role: .destructive) { store.deleteExtra(e.id) } label: { Image(systemName: "trash") }
                        .buttonStyle(.borderless)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .card()
    }
}

struct ExtraForm: View {
    let period: Period
    let onSave: (Date, Int64, String) -> Void
    let onCancel: () -> Void
    @State var date = Date().dayStart
    @State var amountText = ""
    @State var note = ""

    var body: some View {
        NavigationStack {
            Form {
                DatePicker("Ngày nhận", selection: $date, displayedComponents: .date)
                TextField("Số tiền (₫)", text: $amountText).keyboardType(.numbersAndPunctuation)
                TextField("Ghi chú", text: $note)
            }
            .navigationTitle("Thêm khoản")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Huỷ", action: onCancel) }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") {
                        let digits = amountText.filter { $0.isNumber || $0 == "-" }
                        if let v = Int64(digits), v != 0 { onSave(date.dayStart, v, note) }
                    }
                }
            }
        }
    }
}

// MARK: - Cài đặt lương

struct MoneyField: View {
    let title: String
    @Binding var value: Int64
    @State var text = ""
    @State var loaded = false

    var body: some View {
        HStack {
            Text(title)
            Spacer()
            TextField("0", text: $text)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: 160)
                .onChange(of: text) { t in
                    let digits = t.filter { $0.isNumber }
                    value = Int64(digits) ?? 0
                }
            Text("₫").foregroundColor(.secondary)
        }
        .onAppear {
            if !loaded {
                text = value == 0 ? "" : String(value)
                loaded = true
            }
        }
    }
}

struct DecimalField: View {
    let title: String
    @Binding var value: Double
    var suffix = ""
    @State var text = ""
    @State var loaded = false

    var body: some View {
        HStack {
            Text(title)
            Spacer()
            TextField("0", text: $text)
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: 100)
                .onChange(of: text) { t in
                    value = Double(t.replacingOccurrences(of: ",", with: ".")) ?? 0
                }
            if !suffix.isEmpty { Text(suffix).foregroundColor(.secondary) }
        }
        .onAppear {
            if !loaded {
                text = value == 0 ? "" : fmtNum(value)
                loaded = true
            }
        }
    }
}

struct PayrollSettingsView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @State var s: PayrollSettings

    init(initial: PayrollSettings) {
        _s = State(initialValue: initial)
    }

    private func bit(_ kp: WritableKeyPath<PayrollSettings, Int>, _ i: Int) -> Binding<Bool> {
        Binding(
            get: { (s[keyPath: kp] & (1 << i)) != 0 },
            set: { on in
                if on { s[keyPath: kp] |= (1 << i) } else { s[keyPath: kp] &= ~(1 << i) }
            }
        )
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Lương") {
                    MoneyField(title: "Lương tháng", value: $s.monthly)
                    MoneyField(title: "Phụ cấp mỗi kỳ", value: $s.allowance)
                    Toggle("Tự tính công chuẩn theo lịch", isOn: $s.stdAuto)
                    if !s.stdAuto {
                        DecimalField(title: "Công chuẩn", value: $s.stdDays, suffix: "công")
                    }
                    DecimalField(title: "Số giờ làm mỗi ngày", value: $s.hoursPerDay, suffix: "giờ")
                    Toggle("Nghỉ phép vẫn hưởng lương", isOn: $s.paidLeave)
                    Toggle("Tự tính lương ngày lễ", isOn: $s.autoHoliday)
                }
                Section("Thứ 7 làm việc (tuần trong tháng)") {
                    ForEach(0..<5, id: \.self) { i in
                        Toggle("Thứ 7 thứ \(i + 1)", isOn: bit(\.satWorkMask, i))
                    }
                    Picker("Số công mỗi thứ 7", selection: $s.satDayValue) {
                        Text("0,5").tag(0.5)
                        Text("1").tag(1.0)
                    }.pickerStyle(.segmented)
                }
                Section("Chủ nhật làm việc (tuần trong tháng)") {
                    ForEach(0..<5, id: \.self) { i in
                        Toggle("Chủ nhật thứ \(i + 1)", isOn: bit(\.sunWorkMask, i))
                    }
                    Picker("Số công mỗi Chủ nhật", selection: $s.sunDayValue) {
                        Text("0,5").tag(0.5)
                        Text("1").tag(1.0)
                    }.pickerStyle(.segmented)
                }
                Section("Hệ số tăng ca") {
                    Stepper("Ngày thường: \(s.rateNormal)%", value: $s.rateNormal, in: 100...1000, step: 10)
                    Stepper("Thứ 7 nghỉ: \(s.rateSaturday)%", value: $s.rateSaturday, in: 100...1000, step: 10)
                    Stepper("Chủ nhật nghỉ: \(s.rateWeekend)%", value: $s.rateWeekend, in: 100...1000, step: 10)
                    Stepper("Ngày lễ: \(s.rateHoliday)%", value: $s.rateHoliday, in: 100...1000, step: 10)
                    Toggle("Đi làm ngày nghỉ chỉ tính theo giờ OT", isOn: $s.restByHours)
                }
                Section("Lương dùng để tính OT") {
                    Picker("Lấy từ", selection: $s.otBaseMode) {
                        Text("Lương cơ bản").tag(0)
                        Text("Tổng lương").tag(1)
                        Text("Nhập riêng").tag(2)
                    }.pickerStyle(.segmented)
                    if s.otBaseMode == 0 {
                        MoneyField(title: "Lương cơ bản", value: $s.basic)
                    }
                    if s.otBaseMode == 2 {
                        MoneyField(title: "Số tiền", value: $s.otBaseAmount)
                    }
                    DecimalField(title: "Công chuẩn riêng cho OT", value: $s.otStdDays, suffix: "công")
                }
                Section("Bảo hiểm") {
                    Toggle("Trừ bảo hiểm", isOn: $s.insOn)
                    if s.insOn {
                        MoneyField(title: "Mức lương đóng", value: $s.insBase)
                        DecimalField(title: "Tỷ lệ đóng", value: $s.insPct, suffix: "%")
                    }
                }
            }
            .navigationTitle("Cài đặt lương")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Huỷ") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") {
                        if s.stdDays <= 0 { s.stdDays = 23 }
                        if s.insPct <= 0 { s.insPct = 10.5 }
                        if s.hoursPerDay < 1 { s.hoursPerDay = 8 }
                        store.savePayrollSettings(s)
                        dismiss()
                    }
                }
            }
        }
    }
}
